CREATE TABLE DETTAGLIO_ORDINE
(
    id_ordine        int            NOT NULL,
    id_articolo      int            NOT NULL,
    quantita         int            NOT NULL,
    prezzo_applicato decimal(10, 2) NOT NULL,
    PRIMARY KEY (id_ordine, id_articolo),
    CONSTRAINT dettaglio_ordine_ibfk_1
        FOREIGN KEY (id_ordine) REFERENCES deliveroo.ORDINE (id)
            ON DELETE CASCADE,
    CONSTRAINT dettaglio_ordine_ibfk_2
        FOREIGN KEY (id_articolo) REFERENCES deliveroo.ARTICOLO (idArticolo)
            ON DELETE CASCADE
);

CREATE INDEX id_articolo
    ON DETTAGLIO_ORDINE (id_articolo);

INSERT INTO Deliveroo.DETTAGLIO_ORDINE (id_ordine, id_articolo, quantita, prezzo_applicato) VALUES (57, 12, 1, 8.00);
INSERT INTO Deliveroo.DETTAGLIO_ORDINE (id_ordine, id_articolo, quantita, prezzo_applicato) VALUES (57, 13, 1, 7.00);
INSERT INTO Deliveroo.DETTAGLIO_ORDINE (id_ordine, id_articolo, quantita, prezzo_applicato) VALUES (58, 12, 1, 8.00);
INSERT INTO Deliveroo.DETTAGLIO_ORDINE (id_ordine, id_articolo, quantita, prezzo_applicato) VALUES (61, 11, 1, 7.50);
INSERT INTO Deliveroo.DETTAGLIO_ORDINE (id_ordine, id_articolo, quantita, prezzo_applicato) VALUES (62, 11, 1, 7.50);
INSERT INTO Deliveroo.DETTAGLIO_ORDINE (id_ordine, id_articolo, quantita, prezzo_applicato) VALUES (63, 11, 1, 7.50);
INSERT INTO Deliveroo.DETTAGLIO_ORDINE (id_ordine, id_articolo, quantita, prezzo_applicato) VALUES (63, 12, 2, 8.00);
INSERT INTO Deliveroo.DETTAGLIO_ORDINE (id_ordine, id_articolo, quantita, prezzo_applicato) VALUES (63, 28, 9, 0.00);
INSERT INTO Deliveroo.DETTAGLIO_ORDINE (id_ordine, id_articolo, quantita, prezzo_applicato) VALUES (64, 11, 2, 7.50);
