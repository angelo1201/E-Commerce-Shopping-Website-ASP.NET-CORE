CREATE TABLE ARTICOLO
(
    idArticolo     int AUTO_INCREMENT
        PRIMARY KEY,
    nome           varchar(255)   NOT NULL,
    foto           varchar(50)    NULL,
    prezzoListino  decimal(10, 2) NOT NULL,
    numeroDiOrdini int DEFAULT 0  NULL,
    descrizione    varchar(500)   NULL
);

INSERT INTO Deliveroo.ARTICOLO (idArticolo, nome, foto, prezzoListino, numeroDiOrdini, descrizione) VALUES (11, 'Gin Tonic', 'gin_tonic.jpg', 7.50, 16, 'Un cocktail classico e rinfrescante a base di gin e acqua tonica, guarnito con lime.');
INSERT INTO Deliveroo.ARTICOLO (idArticolo, nome, foto, prezzoListino, numeroDiOrdini, descrizione) VALUES (12, 'Negroni', 'negroni.jpg', 8.00, 68, 'Un mix amaro e aromatico di gin, vermouth rosso e Campari, con fetta d’arancia.');
INSERT INTO Deliveroo.ARTICOLO (idArticolo, nome, foto, prezzoListino, numeroDiOrdini, descrizione) VALUES (13, 'Mojito', 'mojito.jpg', 7.00, 0, 'Rum bianco, zucchero, lime, menta fresca e soda per un cocktail cubano frizzante.');
INSERT INTO Deliveroo.ARTICOLO (idArticolo, nome, foto, prezzoListino, numeroDiOrdini, descrizione) VALUES (14, 'Spritz', 'spritz.jpg', 6.50, 0, 'Aperol, prosecco e soda in un classico aperitivo italiano dal gusto leggermente amaro.');
INSERT INTO Deliveroo.ARTICOLO (idArticolo, nome, foto, prezzoListino, numeroDiOrdini, descrizione) VALUES (15, 'Martini', 'martini.jpg', 9.00, 0, 'Gin e vermouth secco, elegante e forte, servito con oliva o scorza di limone.');
INSERT INTO Deliveroo.ARTICOLO (idArticolo, nome, foto, prezzoListino, numeroDiOrdini, descrizione) VALUES (16, 'Margarita', 'margarita.jpg', 8.50, 0, 'Tequila, triple sec e succo di lime per un mix acidulo e deciso.');
INSERT INTO Deliveroo.ARTICOLO (idArticolo, nome, foto, prezzoListino, numeroDiOrdini, descrizione) VALUES (17, 'Bloody Mary', 'bloody_mary.jpg', 8.00, 0, 'Vodka, succo di pomodoro e spezie, ideale come brunch cocktail.');
INSERT INTO Deliveroo.ARTICOLO (idArticolo, nome, foto, prezzoListino, numeroDiOrdini, descrizione) VALUES (18, 'Cosmopolitan', 'cosmopolitan.jpg', 9.00, 0, 'Vodka, triple sec, succo di lime e cranberry per un drink fruttato e femminile.');
INSERT INTO Deliveroo.ARTICOLO (idArticolo, nome, foto, prezzoListino, numeroDiOrdini, descrizione) VALUES (19, 'Caipirinha', 'caipirinha.jpg', 7.00, 0, 'Cocktail brasiliano con cachaça, lime e zucchero di canna.');
INSERT INTO Deliveroo.ARTICOLO (idArticolo, nome, foto, prezzoListino, numeroDiOrdini, descrizione) VALUES (20, 'Old Fashioned', 'old_fashioned.jpg', 9.50, 0, 'Whisky, zucchero, bitter e una scorza d’arancia, perfetto per chi ama i classici.');
INSERT INTO Deliveroo.ARTICOLO (idArticolo, nome, foto, prezzoListino, numeroDiOrdini, descrizione) VALUES (21, 'Daiquiri', 'daiquiri.jpg', 7.50, 0, 'Rum bianco, lime e zucchero per un cocktail fresco e semplice.');
INSERT INTO Deliveroo.ARTICOLO (idArticolo, nome, foto, prezzoListino, numeroDiOrdini, descrizione) VALUES (23, 'Manhattan', 'manhattan.jpg', 8.00, 0, 'descrizione...');
INSERT INTO Deliveroo.ARTICOLO (idArticolo, nome, foto, prezzoListino, numeroDiOrdini, descrizione) VALUES (24, 'Espresso Martini', 'espresso_martini.jpg', 9.00, 0, 'descrizione...');
INSERT INTO Deliveroo.ARTICOLO (idArticolo, nome, foto, prezzoListino, numeroDiOrdini, descrizione) VALUES (25, 'Tom Collins', 'tom_collins.jpg', 10.00, 0, 'descrizione...');
INSERT INTO Deliveroo.ARTICOLO (idArticolo, nome, foto, prezzoListino, numeroDiOrdini, descrizione) VALUES (28, 'test', 'test.jpg', 0.00, 81, 'le patatine piacciono a tutti');
