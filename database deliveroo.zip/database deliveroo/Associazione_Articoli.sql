CREATE TABLE Associazione_Articoli
(
    IdArticolo_X       int                                 NOT NULL,
    IdArticolo_Y       int                                 NOT NULL,
    Frequenza          int       DEFAULT 1                 NULL,
    UltimaAssociazione timestamp DEFAULT CURRENT_TIMESTAMP NULL,
    PRIMARY KEY (IdArticolo_X, IdArticolo_Y),
    CONSTRAINT associazione_articoli_ibfk_1
        FOREIGN KEY (IdArticolo_X) REFERENCES deliveroo.Articolo (idArticolo),
    CONSTRAINT associazione_articoli_ibfk_2
        FOREIGN KEY (IdArticolo_Y) REFERENCES deliveroo.Articolo (idArticolo)
);

CREATE INDEX IdArticolo_Y
    ON Associazione_Articoli (IdArticolo_Y);

