CREATE TABLE ORDINE
(
    id            int AUTO_INCREMENT
        PRIMARY KEY,
    data          date           NOT NULL,
    nomeCliente   varchar(255)   NOT NULL,
    indirizzo     text           NOT NULL,
    importoTotale decimal(10, 2) NOT NULL
);

INSERT INTO Deliveroo.ORDINE (id, data, nomeCliente, indirizzo, importoTotale) VALUES (1, '2025-03-21', 'Mario Rossi', 'Via Roma 10, Milano', 8.50);
INSERT INTO Deliveroo.ORDINE (id, data, nomeCliente, indirizzo, importoTotale) VALUES (2, '2025-03-21', 'Giulia Bianchi', 'Corso Italia 5, Torino', 12.00);
INSERT INTO Deliveroo.ORDINE (id, data, nomeCliente, indirizzo, importoTotale) VALUES (3, '2025-03-21', 'Luca Verdi', 'Piazza Duomo 3, Firenze', 7.30);
INSERT INTO Deliveroo.ORDINE (id, data, nomeCliente, indirizzo, importoTotale) VALUES (57, '2025-05-09', 'a', 'a', 75.00);
INSERT INTO Deliveroo.ORDINE (id, data, nomeCliente, indirizzo, importoTotale) VALUES (58, '2025-05-09', 'fas', 'asdf', 16.00);
INSERT INTO Deliveroo.ORDINE (id, data, nomeCliente, indirizzo, importoTotale) VALUES (61, '2025-05-09', 'dfs', 'dsaf', 7.50);
INSERT INTO Deliveroo.ORDINE (id, data, nomeCliente, indirizzo, importoTotale) VALUES (62, '2025-05-09', 'fsda', 'fasd', 7.50);
INSERT INTO Deliveroo.ORDINE (id, data, nomeCliente, indirizzo, importoTotale) VALUES (63, '2025-05-09', 'sd', 'dsaf', 23.50);
INSERT INTO Deliveroo.ORDINE (id, data, nomeCliente, indirizzo, importoTotale) VALUES (64, '2025-05-09', 'dfs', 'dfs', 15.00);
