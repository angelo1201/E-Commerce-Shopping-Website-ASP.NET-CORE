using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using Deliveroo.Models;
using Deliveroo.Services;

namespace Deliveroo.Controllers;

public class HomeController : Controller
{
    private readonly ILogger<HomeController> _logger;
    private readonly IConfiguration _configuration; // Riferimento al file di configurazione
    private readonly ISession _session; // Memorizza i dati della sessione
    private readonly SuggerimentoService _suggerimentoService;
    
    private GestioneDati gestione;
    private GestioneSessione gestioneSessione;
    
    public HomeController(ILogger<HomeController> logger, IHttpContextAccessor httpContextAccessor, IConfiguration configuration, SuggerimentoService suggerimentoService)
    {
        _logger = logger;
        _session = httpContextAccessor.HttpContext.Session;
        _configuration = configuration;
        _suggerimentoService = suggerimentoService;
        
        _session.SetInt32("contatore", 0);
        gestione = new GestioneDati();
        gestioneSessione = new GestioneSessione(_session);
    }

    public IActionResult Index()
    {
        return View();
    }

    public IActionResult Privacy()
    {
        return View();
    }

    // --- Visualizza un articolo ---
    public IActionResult Articolo(int id)
    {
        Articolo a = gestione.RecuperaArticolo(id);
        if (a != null)
        {
            return View(a);
        }
        else
        {
            return View("Non Trovato");
        }
    }

    // --- Elenco articoli ---
    public IActionResult ElencoArticoli()
    {
        List<Articolo> list = gestione.RecuperaTuttiArticoli();
        return View(list);
    }

    // --- Aggiunta di un nuovo articolo ---
    public IActionResult AggiungiArticolo()
    {
        return View();
    }
    
    public IActionResult Login() //apre il form
    {
        return View(new System.Net.NetworkCredential());
    }

    [HttpPost] //riceve l'oggetto
    public IActionResult Login(System.Net.NetworkCredential credential)
    {
        //da finire qua e nel layout.cshtml se logged mi fa vedere aggiungiArticoli
        var cred= _configuration.GetRequiredSection("Credentials");
        string adminName = cred["UserName"];
        string password = cred["Password"];
        string nomeUtente = credential.UserName;
        string pwdUtente = credential.Password;
        if (nomeUtente == adminName && pwdUtente == password)
        {
            _session.SetString("user","admin");
            return RedirectToAction("Index");
        }
        else
        {
            ViewData["errore"] = "password errata";
            return View(credential);
        }
        
    }
    public IActionResult Logout()
    {
        _session.Clear(); // Svuota tutti i dati della sessione
        return RedirectToAction("Index");
    }

    [HttpPost]
    public IActionResult AggiungiArticolo(Articolo articolo)
    {
        if (ModelState.IsValid)
        {
            string risultato = gestione.AggiungiArticolo(articolo);
            if (risultato == "ok")
            {
                return RedirectToAction("ElencoArticoli");
            }
            ModelState.AddModelError("", risultato);
        }
        return View(articolo);
    }

    // --- Modifica un articolo ---
    public IActionResult ModificaArticolo(int id)
    {
        Articolo articolo = gestione.RecuperaArticolo(id);
        if (articolo == null)
        {
            return NotFound();
        }

        return View(articolo);
    }

    [HttpPost]
    public IActionResult ModificaArticolo(Articolo articolo)
    {
        if (ModelState.IsValid)
        {
            string risultato = gestione.UpdateArticolo(articolo);
            if (risultato == "ok")
            {
                return RedirectToAction("ElencoArticoli");
            }
            ModelState.AddModelError("", risultato);
        }
        return View(articolo);
    }

    // --- Eliminazione articolo ---
    public IActionResult EliminaArticolo(int id)
    {
        string risultato = gestione.DeleteArticolo(id);
        if (risultato != "ok")
        {
            ModelState.AddModelError("", risultato);
        }
        return RedirectToAction("ElencoArticoli");
    }

    // --- Elenco Ordini ---
    public IActionResult ElencoOrdini()
    {
        List<Ordine> ordini = gestione.GetAllOrdini();
        return View(ordini);
    }

    // --- Inserisci un nuovo ordine ---
    [HttpPost]
    public IActionResult InserisciOrdine(string nomeCliente, string indirizzo)
    {
        Carrello c = gestioneSessione.PrendiCarrello();
    
        if (c == null || c.ListaArticolo.Count == 0)
        {
            ModelState.AddModelError("", "Il carrello è vuoto.");
            return RedirectToAction("MostraCarrello");
        }

        // Calcola il totale
        decimal totale = c.ListaArticolo.Sum(a => a.PrezzoListino);

        // Crea l'ordine
        Ordine nuovoOrdine = new Ordine
        {
            Data = DateTime.Now,
            NomeCliente = nomeCliente,
            Indirizzo = indirizzo,
            ImportoTotale = (double)totale
        };

        // Salva l'ordine
        string risultato = gestione.InserisciOrdine(nuovoOrdine);
    
        if (risultato == "ok")
        {
            c.SvuotaCarrello();
            gestioneSessione.SalvaCarrello(c);
            TempData["MessaggioOrdine"] = "Ordine effettuato con successo!";
            return RedirectToAction("ElencoOrdini");
        }
    
        ModelState.AddModelError("", risultato);
        return RedirectToAction("MostraCarrello");
    }


    public IActionResult AggiungiAlCarrello(int id, int quantita)
    {
        Articolo a = gestione.RecuperaArticolo(id);
        Carrello c = gestioneSessione.PrendiCarrello();
    
        for (int i = 0; i < quantita; i++)
        {
            c.Aggiungi(a);
        }
        gestioneSessione.SalvaCarrello(c);
        TempData["MessaggioCarrello"] = "Articolo aggiunto al carrello!";
        return RedirectToAction("ElencoArticoli");
    }

    // --- Mostra il carrello ---
    public IActionResult MostraCarrello()
    {
        Carrello c = gestioneSessione.PrendiCarrello();
        List<Articolo> lista = c.ListaArticolo;
        return View(lista);
    }

    // --- Svuota il carrello ---
    public IActionResult CancellaSelezione()
    {
        Carrello c = gestioneSessione.PrendiCarrello();
        c.SvuotaCarrello();
        gestioneSessione.SalvaCarrello(c);
        return RedirectToAction("MostraCarrello");
    }
    public IActionResult RimuoviUno(string nome)
    {
        Carrello c = gestioneSessione.PrendiCarrello();
        if (c != null)
        {
            Articolo articoloDaRimuovere = c.ListaArticolo.FirstOrDefault(a => a.Nome == nome);
            if (articoloDaRimuovere != null)
            {
                c.Rimuovi(articoloDaRimuovere); // rimuove solo la prima occorrenza
                gestioneSessione.SalvaCarrello(c);
            }
        }

        return RedirectToAction("MostraCarrello");
    }
    public IActionResult AggiungiiUno(string nome)
    {
        Carrello c = gestioneSessione.PrendiCarrello();
        if (c != null)
        {
            Articolo articoloDaAggiungere = c.ListaArticolo.FirstOrDefault(a => a.Nome == nome);
            if (articoloDaAggiungere != null)
            {
                c.Aggiungi(articoloDaAggiungere); // rimuove solo la prima occorrenza
                gestioneSessione.SalvaCarrello(c);
            }
        }

        return RedirectToAction("MostraCarrello");
    }
    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
    
    public IActionResult EliminaTutti(string nome)
    {
        Carrello c = gestioneSessione.PrendiCarrello();
        c.ListaArticolo.RemoveAll(a => a.Nome == nome);
        gestioneSessione.SalvaCarrello(c);
        return RedirectToAction("MostraCarrello");
    }
    public IActionResult DatiCliente()
    {
        return View(new Ordine()); // Ordine con proprietà NomeCliente e Indirizzo
    }
    
    // GET: InserisciDatiCliente
    public IActionResult InserisciDatiCliente()
    {
        Carrello c = gestioneSessione.PrendiCarrello();

        if (c == null || c.ListaArticolo.Count == 0)
        {
            TempData["MessaggioErrore"] = "Il carrello è vuoto.";
            return RedirectToAction("MostraCarrello");
        }

        decimal totale = c.ListaArticolo.Sum(a => a.PrezzoListino);
        Ordine ordine = new Ordine
        {
            ImportoTotale = (double)totale
        };

        // Passo un ordine vuoto solo per il binding del form
        return View(ordine);
    }


    [HttpPost]
    public IActionResult InserisciDatiCliente(string nomeCliente, string indirizzo, DateTime data, double importoTotale)
    {
        Carrello c = gestioneSessione.PrendiCarrello();

        if (c == null || c.ListaArticolo.Count == 0)
        {
            TempData["MessaggioErrore"] = "Il carrello è vuoto.";
            return RedirectToAction("MostraCarrello");
        }

        // Salva il nome del cliente in sessione per futuri riferimenti
        HttpContext.Session.SetString("NomeCliente", nomeCliente);

        Ordine nuovoOrdine = new Ordine
        {
            NomeCliente = nomeCliente,
            Indirizzo = indirizzo,
            Data = DateTime.Now,
            ImportoTotale = c.ListaArticolo.Sum(a => (double)a.PrezzoListino)
        };

        string risultato = gestione.InserisciOrdine(nuovoOrdine);

        if (risultato == "ok")
        {
            int ultimoId = gestione.GetAllOrdini().Last().Id;

            foreach (var articolo in c.ListaArticolo)
            {
                int quantita = c.ListaArticolo.Count(a => a.IdArticolo == articolo.IdArticolo);
                gestione.InserisciDettaglioOrdine(ultimoId, articolo.IdArticolo, quantita, articolo.PrezzoListino);
                gestione.AggiornaNumeroOrdini(articolo.IdArticolo, quantita);
            }

            // AGGIUNGI QUESTA CHIAMATA PER AGGIORNARE LE ASSOCIAZIONI
            _suggerimentoService.AggiornaAssociazioni(ultimoId);

            c.SvuotaCarrello();
            gestioneSessione.SalvaCarrello(c);

            return RedirectToAction("ConfermaOrdine", new { id = ultimoId });
        }

        ViewBag.Messaggio = risultato;
        return View("InserisciDatiCliente", nuovoOrdine);
    }
    // GET: ConfermaOrdine
    public IActionResult ConfermaOrdine(int id)
    {
        Ordine ordine = gestione.RecuperaOrdine(id);
        if (ordine == null)
        {
            return NotFound();
        }

        // Recupera i dettagli
        ordine.Articoli = gestione.RecuperaDettagliPerOrdine(id)
            .Select(d => gestione.RecuperaArticolo(d.IdArticolo))
            .Where(a => a != null)
            .ToList();

        return View(ordine);
    }

    [HttpPost]
    public IActionResult EliminaOrdine(int id)
    {
        gestione.EliminaOrdine(id);  // metodo da aggiungere in GestioneDati
        return RedirectToAction("ElencoOrdini");
    }

    public IActionResult Suggerimenti(int idOrdine)
{
    var dettagliOrdine = gestione.RecuperaDettagliPerOrdine(idOrdine);
    var articoliOrdineIds = dettagliOrdine.Select(d => d.IdArticolo).Distinct().ToList();

    List<Articolo> suggerimenti = new List<Articolo>();

    if (articoliOrdineIds.Any())
    {
        // Ottieni tutte le associazioni legate agli articoli dell'ordine
        var tutteAssociazioni = articoliOrdineIds
            .SelectMany(id => gestione.GetAssociazioniByArticolo(id))
            .Where(a =>
                // Includi solo associazioni con articoli non già nell'ordine
                !articoliOrdineIds.Contains(a.IdArticolo_X == idOrdine ? a.IdArticolo_Y : a.IdArticolo_X))
            .ToList();

        // Raggruppa per articolo suggerito, somma le frequenze, ordina
        var suggerimentiPonderati = tutteAssociazioni
            .GroupBy(a => articoliOrdineIds.Contains(a.IdArticolo_X) ? a.IdArticolo_Y : a.IdArticolo_X)
            .Select(g => new
            {
                IdArticolo = g.Key,
                FrequenzaTotale = g.Sum(x => x.Frequenza),
                DataRecente = g.Max(x => x.UltimaAssociazione)
            })
            .OrderByDescending(x => x.FrequenzaTotale)
            .ThenByDescending(x => x.DataRecente)
            .Take(3)
            .ToList();

        // Recupera gli articoli da mostrare come suggerimenti
        suggerimenti = suggerimentiPonderati
            .Select(x => gestione.RecuperaArticolo(x.IdArticolo))
            .Where(a => a != null)
            .ToList();
    }

    // Se non bastano i suggerimenti, completa con articoli popolari esclusi
    if (suggerimenti.Count < 3)
    {
        var articoliMancanti = 3 - suggerimenti.Count;
        var articoliPopolari = gestione.RecuperaTuttiArticoli()
            .Where(a =>
                !articoliOrdineIds.Contains(a.IdArticolo) &&
                !suggerimenti.Any(s => s.IdArticolo == a.IdArticolo))
            .OrderByDescending(a => a.NumeroDiOrdini)
            .Take(articoliMancanti)
            .ToList();

        suggerimenti.AddRange(articoliPopolari);
    }

    return View(suggerimenti.Take(3).ToList());
}

    [HttpPost]
    [ActionName("ConfermaOrdine")] // Mantiene lo stesso nome per il routing
    public IActionResult ProcessaConfermaOrdine(int idOrdine) 
    {
        _suggerimentoService.AggiornaAssociazioni(idOrdine);
        return RedirectToAction("Grazie", new { idOrdine });
    }
    public IActionResult Grazie(int idOrdine)
    {
        ViewBag.IdOrdine = idOrdine;
        return View();
    }
    
    // --- Visualizza i miei ordini (per utente normale) ---
    public IActionResult MieiOrdini()
    {
        // Recupera il nome del cliente dalla sessione (se memorizzato durante il checkout)
        string nomeCliente = HttpContext.Session.GetString("NomeCliente");
    
        if (string.IsNullOrEmpty(nomeCliente))
        {
            // Se non c'è un nome cliente in sessione, mostra messaggio
            ViewBag.Messaggio = "Accedi per vedere i tuoi ordini";
            return View(new List<Ordine>());
        }

        // Filtra gli ordini per il cliente corrente
        List<Ordine> mieiOrdini = gestione.GetAllOrdini()
            .Where(o => o.NomeCliente == nomeCliente)
            .OrderByDescending(o => o.Data)  // Ordina per data decrescente
            .ToList();

        return View(mieiOrdini);
    }

// --- Dettagli ordine per utente normale ---
    public IActionResult DettagliOrdine(int id)
    {
        // Verifica che l'ordine appartenga all'utente corrente
        string nomeCliente = HttpContext.Session.GetString("NomeCliente");
        Ordine ordine = gestione.RecuperaOrdine(id);
    
        if (ordine == null || (nomeCliente != null && ordine.NomeCliente != nomeCliente))
        {
            return NotFound();
        }

        // Recupera i dettagli dell'ordine
        var dettagli = gestione.RecuperaDettagliPerOrdine(id);
        ordine.Articoli = new List<Articolo>();
    
        foreach (var dettaglio in dettagli)
        {
            var articolo = gestione.RecuperaArticolo(dettaglio.IdArticolo);
            if (articolo != null)
            {
                // Aggiungi la quantità all'articolo
                articolo.NumeroDiOrdini = dettaglio.Quantita;
                ordine.Articoli.Add(articolo);
            }
        }

        return View(ordine);
    }
    // --- Elenco articoli per admin (con funzionalità aggiuntive) ---
    public IActionResult AdminElencoArticoli()
    {
        // Verifica che l'utente sia admin
        if (_session.GetString("user") != "admin")
        {
            TempData["MessaggioErrore"] = "Accesso negato. Effettua il login come amministratore.";
            return RedirectToAction("Login");
        }

        List<Articolo> list = gestione.RecuperaTuttiArticoli();
        return View(list);
    }
    
}
