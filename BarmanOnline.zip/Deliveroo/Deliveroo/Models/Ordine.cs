using System.Collections;

namespace Deliveroo.Models;

public class Ordine
{
    public int Id { get; set; }
    public DateTime Data { get; set; }
    public string NomeCliente { get; set; }
    public string Indirizzo { get; set; }
    public double ImportoTotale { get; set; }
    public List<Articolo> Articoli { get; set; } = new();
    
}