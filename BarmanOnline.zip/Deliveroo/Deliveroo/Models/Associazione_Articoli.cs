namespace Deliveroo.Models;

public class Associazione_Articoli
{
    public int IdArticolo_X { get; set; }
    public int IdArticolo_Y { get; set; }
    
    public int Frequenza { get; set; }
    public DateTime UltimaAssociazione { get; set; }
}