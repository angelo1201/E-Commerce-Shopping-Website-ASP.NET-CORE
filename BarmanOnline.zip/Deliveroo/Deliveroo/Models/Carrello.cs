namespace Deliveroo.Models;

public class Carrello
{
    public List<Articolo> ListaArticolo { get; set; }

    public Carrello()
    {
        ListaArticolo = new List<Articolo>();
    }
    public void Aggiungi(Articolo a)
    {
        ListaArticolo.Add(a);
    }

    public void Rimuovi(Articolo a)
    {
        ListaArticolo.Remove(a);
    }
    public void SvuotaCarrello()
    {
        ListaArticolo.Clear();
    }
}