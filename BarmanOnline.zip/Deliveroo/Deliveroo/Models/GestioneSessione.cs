namespace Deliveroo.Models;

using System.Text.Json;
using MySqlX.XDevAPI;

public class GestioneSessione
{
    private ISession sessione;

    public GestioneSessione(ISession sessione)
    {
        this.sessione = sessione;
    }
    public Carrello PrendiCarrello()
    {
        //prende il carrello dalla sessione
        //la sessione momorizza il carrello
        //come stringa json
        Carrello c;
        if (sessione.Keys.Contains("carrello"))
        {
            string appo = sessione.GetString("carrello"); 
            c = JsonSerializer.Deserialize<Carrello>(appo);
        }
        else
        {
            c = new Carrello();
        }
        return c;
    }

    public void SalvaCarrello(Carrello c)
    {
        string appo = JsonSerializer.Serialize(c);
        sessione.SetString("carrello",appo);
    }
}