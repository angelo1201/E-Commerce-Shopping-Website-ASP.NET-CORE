using System.Text;
using MySql.Data.MySqlClient;
using Mysqlx;
namespace Deliveroo.Models;

public class GestioneDati
{
    private MySqlConnection con;
    
    public GestioneDati()
    {
        string s = "database=Deliveroo;host=localhost;port=3306;user=root;pwd=angelo20041201";
        con = new MySqlConnection(s);
        con.Open();
    }

    public List<Ordine> GetAllOrdini()
    {
        string query = "SELECT * FROM Ordine ORDER BY id";
        MySqlCommand cmd = new MySqlCommand(query, con);
        MySqlDataReader reader = cmd.ExecuteReader();
        List<Ordine> ris = new List<Ordine>();
        while (reader.Read())
        {
            Ordine o = new Ordine();
            o.Id = (int)reader["id"];
            o.Data = (DateTime)reader["data"];
            o.NomeCliente = (string)reader["nomeCliente"];
            o.Indirizzo = (string)reader["indirizzo"];
            o.ImportoTotale = Convert.ToDouble(reader["importoTotale"]);
            ris.Add(o);
        }
        reader.Close();
        return ris;
    }

    public string InserisciOrdine(Ordine o)
    {
        string risultato = "ok";

        // Inserisci ordine
        string queryOrdine = "INSERT INTO Ordine (data, nomeCliente, indirizzo, importoTotale) VALUES (@data, @nomeCLiente, @indirizzo, @importoTotale)";
        MySqlCommand cmdOrdine = new MySqlCommand(queryOrdine, con);
        cmdOrdine.Parameters.AddWithValue("@data", o.Data);
        cmdOrdine.Parameters.AddWithValue("@nomeCLiente", o.NomeCliente);
        cmdOrdine.Parameters.AddWithValue("@indirizzo", o.Indirizzo);
        cmdOrdine.Parameters.AddWithValue("@importoTotale", o.ImportoTotale);

        try
        {
            cmdOrdine.ExecuteNonQuery();

            // Recupera ID appena inserito
            long idOrdine = cmdOrdine.LastInsertedId;

            // Inserisci dettagli ordine per ciascun articolo
            foreach (var articolo in o.Articoli)
            {
                string queryDettaglio = "INSERT INTO DETTAGLIO_ORDINE (id_ordine, id_articolo, quantita, prezzo_applicato) VALUES (@id_ordine, @id_articolo, @quantita, @prezzo_applicato)";
                MySqlCommand cmdDettaglio = new MySqlCommand(queryDettaglio, con);

                cmdDettaglio.Parameters.AddWithValue("@id_ordine", idOrdine);
                cmdDettaglio.Parameters.AddWithValue("@id_articolo", articolo.IdArticolo);
                cmdDettaglio.Parameters.AddWithValue("@quantita", 1); // o articolo.Quantita se esiste
                cmdDettaglio.Parameters.AddWithValue("@prezzo_applicato", articolo.PrezzoListino);

                cmdDettaglio.ExecuteNonQuery();
            }
        }
        catch (Exception e)
        {
            risultato = e.Message;
        }

        return risultato;
    }

    public string UpdateArticolo(Articolo a)
    {
        string query = "UPDATE ARTICOLO SET nome = @nome, foto = @foto, prezzoListino = @prezzoListino, numeroDiOrdini = @numeroDiOrdini, descrizione = @descrizione WHERE idArticolo = @idArticolo";
        

        MySqlCommand cmd = new MySqlCommand(query, con);

        cmd.Parameters.AddWithValue("@idArticolo", a.IdArticolo);
        cmd.Parameters.AddWithValue("@nome", a.Nome);
        cmd.Parameters.AddWithValue("@foto", a.Foto);
        cmd.Parameters.AddWithValue("@prezzoListino", a.PrezzoListino);
        cmd.Parameters.AddWithValue("@numeroDiOrdini", a.NumeroDiOrdini);
        cmd.Parameters.AddWithValue("@descrizione", a.Descrizione);

        string errore = "ok";
        try
        {
            int rowsAffected = cmd.ExecuteNonQuery();
            if (rowsAffected == 0)
            {
                errore = "Nessun articolo aggiornato. Verifica l'ID.";
            }
        }
        catch (Exception e)
        {
            errore = e.Message;
        }

        return errore;
    }
    public string AggiungiArticolo(Articolo a)
    {
        string query = "INSERT INTO ARTICOLO (nome, foto, prezzoListino, numeroDiOrdini, descrizione) VALUES (@nome, @foto, @prezzoListino, @numeroDiOrdini, @descrizione)";
        
    
        MySqlCommand cmd = new MySqlCommand(query, con);
    
        cmd.Parameters.AddWithValue("@nome", a.Nome);
        cmd.Parameters.AddWithValue("@foto", a.Foto);
        cmd.Parameters.AddWithValue("@prezzoListino", a.PrezzoListino);
        cmd.Parameters.AddWithValue("@numeroDiOrdini", a.NumeroDiOrdini);
        cmd.Parameters.AddWithValue("@descrizione", a.Descrizione);

        string errore = "ok";
        try
        {
            cmd.ExecuteNonQuery();
        }
        catch (Exception e)
        {
            errore = e.Message;
        }

        return errore;
    }
    public string DeleteArticolo(int idArticolo)
    {
        string query = "DELETE FROM ARTICOLO WHERE idArticolo = @idArticolo";
    
        MySqlCommand cmd = new MySqlCommand(query, con);
    
        cmd.Parameters.AddWithValue("@idArticolo", idArticolo);

        string errore = "ok";
        try
        {
            int rowsAffected = cmd.ExecuteNonQuery();
            if (rowsAffected == 0)
            {
                errore = "Nessun articolo trovato con l'ID specificato.";
            }
        }
        catch (Exception e)
        {
            errore = e.Message;
        }

        return errore;
    }
    public Articolo RecuperaArticolo(int idArticolo)
    {
        string query = "SELECT * FROM ARTICOLO WHERE idArticolo = @idArticolo";
        MySqlCommand cmd = new MySqlCommand(query, con);
        cmd.Parameters.AddWithValue("@idArticolo", idArticolo);
    
        Articolo articolo = null;
        try
        {
            MySqlDataReader reader = cmd.ExecuteReader();
            if (reader.Read()) // Se esiste un articolo con l'ID specificato
            {
                articolo = new Articolo
                {
                    IdArticolo = (int)reader["idArticolo"],
                    Nome = reader["nome"].ToString(),
                    Foto = reader["foto"] != DBNull.Value ? reader["foto"].ToString() : null,
                    PrezzoListino = reader["prezzoListino"] != DBNull.Value ? Convert.ToDecimal(reader["prezzoListino"]) : 0m,
                    NumeroDiOrdini = reader["numeroDiOrdini"] != DBNull.Value ? Convert.ToInt32(reader["numeroDiOrdini"]) : 0,
                    Descrizione = reader["descrizione"] != DBNull.Value ? reader["descrizione"].ToString() : null
                };
            }
            reader.Close();
        }
        catch (Exception e)
        {
            Console.WriteLine("Errore durante il recupero dell'articolo: " + e.Message);
        }
    
        return articolo;
    }
    public List<Articolo> RecuperaTuttiArticoli()
    {
        string query = "SELECT * FROM ARTICOLO";
        MySqlCommand cmd = new MySqlCommand(query, con);
    
        List<Articolo> articoli = new List<Articolo>();
        try
        {
            MySqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read()) // Itera su tutti gli articoli presenti nel database
            {
                Articolo articolo = new Articolo
                {
                    IdArticolo = (int)reader["idArticolo"],
                    Nome = reader["nome"].ToString(),
                    Foto = reader["foto"] != DBNull.Value ? reader["foto"].ToString() : null,
                    PrezzoListino = reader["prezzoListino"] != DBNull.Value ? Convert.ToDecimal(reader["prezzoListino"]) : 0m,
                    NumeroDiOrdini = reader["numeroDiOrdini"] != DBNull.Value ? Convert.ToInt32(reader["numeroDiOrdini"]) : 0,
                    Descrizione = reader["descrizione"] != DBNull.Value ? reader["descrizione"].ToString() : null
                };
                articoli.Add(articolo);
            }
            reader.Close();
        }
        catch (Exception e)
        {
            Console.WriteLine("Errore durante il recupero degli articoli: " + e.Message);
        }
    
        return articoli;
    }

    public Ordine RecuperaOrdine(int id)
    {
        Ordine ordine = null;
        string query = "SELECT * FROM Ordine WHERE id = @id";

        try
        {
            using (MySqlCommand cmd = new MySqlCommand(query, con))
            {
                cmd.Parameters.AddWithValue("@id", id);

                // Apri la connessione se è chiusa
                if (con.State == System.Data.ConnectionState.Closed)
                    con.Open();

                using (MySqlDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        ordine = new Ordine
                        {
                            Id = Convert.ToInt32(reader["id"]),
                            Data = Convert.ToDateTime(reader["data"]),
                            NomeCliente = reader["nomeCliente"].ToString(),
                            Indirizzo = reader["indirizzo"].ToString(),
                            ImportoTotale = Convert.ToDouble(reader["importoTotale"])
                        };
                    }
                }
            }
        }
        catch (Exception e)
        {
            Console.WriteLine("Errore durante il recupero dell'ordine: " + e.Message);
        }

        return ordine;
    }
    public string CancellaOrdine(int id)
    {
        string query = "DELETE FROM Ordine WHERE id = @id";
        MySqlCommand cmd = new MySqlCommand(query, con);
        cmd.Parameters.AddWithValue("@id", id);

        string risultato = "ok";
        try
        {
            int count = cmd.ExecuteNonQuery();
            if (count == 0)
                risultato = "Nessun ordine trovato con l'ID specificato.";
        }
        catch (Exception e)
        {
            risultato = e.Message;
        }

        return risultato;
    }

    public string AggiornaNumeroOrdini(int idArticolo, int incremento)
    {
        string query = "UPDATE ARTICOLO SET numeroDiOrdini = numeroDiOrdini + @incremento WHERE idArticolo = @idArticolo";
        MySqlCommand cmd = new MySqlCommand(query, con);

        cmd.Parameters.AddWithValue("@incremento", incremento);
        cmd.Parameters.AddWithValue("@idArticolo", idArticolo);

        string risultato = "ok";
        try
        {
            int count = cmd.ExecuteNonQuery();
            if (count == 0)
                risultato = "Articolo non trovato.";
        }
        catch (Exception e)
        {
            risultato = e.Message;
        }

        return risultato;
    }

    public List<DettaglioOrdine> GetAllDettagliOrdine()
    {
        string query = "SELECT * FROM DETTAGLIO_ORDINE";
        MySqlCommand cmd = new MySqlCommand(query, con);
        MySqlDataReader reader = cmd.ExecuteReader();

        List<DettaglioOrdine> dettagli = new List<DettaglioOrdine>();
        while (reader.Read())
        {
            DettaglioOrdine d = new DettaglioOrdine
            {
                IdOrdine = (int)reader["id_ordine"],
                IdArticolo = (int)reader["id_articolo"],
                Quantita = (int)reader["quantita"],
                PrezzoApplicato = Convert.ToDecimal(reader["prezzo_applicato"])
            };
            dettagli.Add(d);
        }
        reader.Close();
        return dettagli;
    }
    public string InserisciDettaglioOrdine(int idOrdine, int idArticolo, int quantita, decimal prezzoApplicato)
    {
        string query = "INSERT INTO DETTAGLIO_ORDINE (id_ordine, id_articolo, quantita, prezzo_applicato) VALUES (@id_ordine, @id_articolo, @quantita, @prezzo_applicato)";
        MySqlCommand cmd = new MySqlCommand(query, con);

        cmd.Parameters.AddWithValue("@id_ordine", idOrdine);
        cmd.Parameters.AddWithValue("@id_articolo", idArticolo);
        cmd.Parameters.AddWithValue("@quantita", quantita); // Quantità è sempre 1
        cmd.Parameters.AddWithValue("@prezzo_applicato", prezzoApplicato);

        string errore = "ok";
        try
        {
            cmd.ExecuteNonQuery();
        }
        catch (Exception e)
        {
            errore = e.Message;
        }
        return errore;
    }

    public string CancellaDettaglioOrdine(int idOrdine, int idArticolo)
    {
        string query = "DELETE FROM DETTAGLIO_ORDINE WHERE id_ordine = @id_ordine AND id_articolo = @id_articolo";
        MySqlCommand cmd = new MySqlCommand(query, con);

        cmd.Parameters.AddWithValue("@id_ordine", idOrdine);
        cmd.Parameters.AddWithValue("@id_articolo", idArticolo);

        string risultato = "ok";
        try
        {
            int count = cmd.ExecuteNonQuery();
            if (count == 0)
                risultato = "Nessun dettaglio ordine trovato con questi ID.";
        }
        catch (Exception e)
        {
            risultato = e.Message;
        }
        return risultato;
    }
    public List<DettaglioOrdine> RecuperaDettagliPerOrdine(int idOrdine)
    {
        string query = "SELECT * FROM DETTAGLIO_ORDINE WHERE id_ordine = @id_ordine";
        MySqlCommand cmd = new MySqlCommand(query, con);

        cmd.Parameters.AddWithValue("@id_ordine", idOrdine);

        List<DettaglioOrdine> dettagli = new List<DettaglioOrdine>();
        try
        {
            MySqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                DettaglioOrdine d = new DettaglioOrdine
                {
                    IdOrdine = (int)reader["id_ordine"],
                    IdArticolo = (int)reader["id_articolo"],
                    Quantita = (int)reader["quantita"],
                    PrezzoApplicato = Convert.ToDecimal(reader["prezzo_applicato"])
                };
                dettagli.Add(d);
            }
            reader.Close();
        }
        catch (Exception e)
        {
            Console.WriteLine("Errore durante il recupero dei dettagli ordine: " + e.Message);
        }

        return dettagli;
    }
    public string AggiornaOrdine(Ordine ordine)
    {
        string query = "UPDATE Ordine SET data = @data, nomeCliente = @nomeCliente, indirizzo = @indirizzo, importoTotale = @importoTotale WHERE id = @id";
    
        MySqlCommand cmd = new MySqlCommand(query, con);
    
        cmd.Parameters.AddWithValue("@id", ordine.Id);
        cmd.Parameters.AddWithValue("@data", ordine.Data);
        cmd.Parameters.AddWithValue("@nomeCliente", ordine.NomeCliente);
        cmd.Parameters.AddWithValue("@indirizzo", ordine.Indirizzo);
        cmd.Parameters.AddWithValue("@importoTotale", ordine.ImportoTotale);
    
        string errore = "ok";
        try
        {
            int rowsAffected = cmd.ExecuteNonQuery();
            if (rowsAffected == 0)
            {
                errore = "Nessun ordine aggiornato. Verifica l'ID.";
            }
        }
        catch (Exception e)
        {
            errore = e.Message;
        }

        return errore;
    }

    public string EliminaOrdine(int id)
    {
        string query = "DELETE FROM Ordine WHERE id = @id";
    
        MySqlCommand cmd = new MySqlCommand(query, con);
    
        cmd.Parameters.AddWithValue("@id", id);

        string risultato = "ok";
        try
        {
            int rowsAffected = cmd.ExecuteNonQuery();
            if (rowsAffected == 0)
            {
                risultato = "Nessun ordine trovato con l'ID specificato.";
            }
        }
        catch (Exception e)
        {
            risultato = e.Message;
        }

        return risultato;
    }
    // Add these methods to your GestioneDati class

public List<Articolo> GetArticoliByOrdine(int idOrdine)
{
    string query = @"
        SELECT a.* 
        FROM ARTICOLO a
        JOIN DETTAGLIO_ORDINE d ON a.idArticolo = d.id_articolo
        WHERE d.id_ordine = @idOrdine";

    var articoli = new List<Articolo>();
    using (var cmd = new MySqlCommand(query, con))
    {
        cmd.Parameters.AddWithValue("@idOrdine", idOrdine);
        
        using (var reader = cmd.ExecuteReader())
        {
            while (reader.Read())
            {
                articoli.Add(new Articolo
                {
                    IdArticolo = (int)reader["idArticolo"],
                    Nome = reader["nome"].ToString(),
                    Foto = reader["foto"] != DBNull.Value ? reader["foto"].ToString() : null,
                    PrezzoListino = reader["prezzoListino"] != DBNull.Value ? Convert.ToDecimal(reader["prezzoListino"]) : 0m,
                    NumeroDiOrdini = reader["numeroDiOrdini"] != DBNull.Value ? Convert.ToInt32(reader["numeroDiOrdini"]) : 0,
                    Descrizione = reader["descrizione"] != DBNull.Value ? reader["descrizione"].ToString() : null
                });
            }
        }
    }
    return articoli;
}

public Associazione_Articoli GetAssociazione(int idX, int idY)
{
    // Ensure X < Y to match the database constraint
    if (idX > idY)
    {
        (idX, idY) = (idY, idX);
    }

    string query = "SELECT * FROM ASSOCIAZIONE_ARTICOLI WHERE IdArticolo_X = @idX AND IdArticolo_Y = @idY";
    
    using (var cmd = new MySqlCommand(query, con))
    {
        cmd.Parameters.AddWithValue("@idX", idX);
        cmd.Parameters.AddWithValue("@idY", idY);
        
        using (var reader = cmd.ExecuteReader())
        {
            if (reader.Read())
            {
                return new Associazione_Articoli
                {
                    IdArticolo_X = (int)reader["IdArticolo_X"],
                    IdArticolo_Y = (int)reader["IdArticolo_Y"],
                    Frequenza = (int)reader["Frequenza"],
                    UltimaAssociazione = Convert.ToDateTime(reader["UltimaAssociazione"])
                };
            }
        }
    }
    return null;
}

public void UpdateAssociazione(Associazione_Articoli associazione)
{
    string query = @"
        UPDATE ASSOCIAZIONE_ARTICOLI 
        SET Frequenza = @frequenza, 
            UltimaAssociazione = @ultimaAssociazione
        WHERE IdArticolo_X = @idX AND IdArticolo_Y = @idY";

    using (var cmd = new MySqlCommand(query, con))
    {
        cmd.Parameters.AddWithValue("@idX", associazione.IdArticolo_X);
        cmd.Parameters.AddWithValue("@idY", associazione.IdArticolo_Y);
        cmd.Parameters.AddWithValue("@frequenza", associazione.Frequenza);
        cmd.Parameters.AddWithValue("@ultimaAssociazione", associazione.UltimaAssociazione);
        
        cmd.ExecuteNonQuery();
    }
}

public void AddAssociazione(Associazione_Articoli associazione)
{
    // Ensure X < Y to match the database constraint
    if (associazione.IdArticolo_X > associazione.IdArticolo_Y)
    {
        (associazione.IdArticolo_X, associazione.IdArticolo_Y) = 
            (associazione.IdArticolo_Y, associazione.IdArticolo_X);
    }

    string query = @"
        INSERT INTO ASSOCIAZIONE_ARTICOLI 
            (IdArticolo_X, IdArticolo_Y, Frequenza, UltimaAssociazione)
        VALUES 
            (@idX, @idY, @frequenza, @ultimaAssociazione)";

    using (var cmd = new MySqlCommand(query, con))
    {
        cmd.Parameters.AddWithValue("@idX", associazione.IdArticolo_X);
        cmd.Parameters.AddWithValue("@idY", associazione.IdArticolo_Y);
        cmd.Parameters.AddWithValue("@frequenza", associazione.Frequenza);
        cmd.Parameters.AddWithValue("@ultimaAssociazione", associazione.UltimaAssociazione);
        
        cmd.ExecuteNonQuery();
    }
}

public List<Associazione_Articoli> GetAssociazioniByArticolo(int idArticolo)
{
    string query = @"
        SELECT * FROM ASSOCIAZIONE_ARTICOLI 
        WHERE IdArticolo_X = @id OR IdArticolo_Y = @id";

    var associazioni = new List<Associazione_Articoli>();
    using (var cmd = new MySqlCommand(query, con))
    {
        cmd.Parameters.AddWithValue("@id", idArticolo);
        
        using (var reader = cmd.ExecuteReader())
        {
            while (reader.Read())
            {
                associazioni.Add(new Associazione_Articoli
                {
                    IdArticolo_X = (int)reader["IdArticolo_X"],
                    IdArticolo_Y = (int)reader["IdArticolo_Y"],
                    Frequenza = (int)reader["Frequenza"],
                    UltimaAssociazione = Convert.ToDateTime(reader["UltimaAssociazione"])
                });
            }
        }
    }
    return associazioni;
}

// Optional: More efficient method for getting associations in bulk
public List<Associazione_Articoli> GetAssociazioniByArticoloRange(int minId)
{
    string query = @"
        SELECT * FROM ASSOCIAZIONE_ARTICOLI 
        WHERE IdArticolo_X >= @minId OR IdArticolo_Y >= @minId";

    var associazioni = new List<Associazione_Articoli>();
    using (var cmd = new MySqlCommand(query, con))
    {
        cmd.Parameters.AddWithValue("@minId", minId);
        
        using (var reader = cmd.ExecuteReader())
        {
            while (reader.Read())
            {
                associazioni.Add(new Associazione_Articoli
                {
                    IdArticolo_X = (int)reader["IdArticolo_X"],
                    IdArticolo_Y = (int)reader["IdArticolo_Y"],
                    Frequenza = (int)reader["Frequenza"],
                    UltimaAssociazione = Convert.ToDateTime(reader["UltimaAssociazione"])
                });
            }
        }
    }
    return associazioni;
}




}