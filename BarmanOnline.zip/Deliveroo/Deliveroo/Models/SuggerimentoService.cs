using Deliveroo.Models;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Deliveroo.Services
{
    public class SuggerimentoService
    {
        private readonly GestioneDati _gestioneDati;

        public SuggerimentoService()
        {
            _gestioneDati = new GestioneDati();
        }

        // Aggiorna le associazioni quando viene effettuato un ordine
        public void AggiornaAssociazioni(int idOrdine)
        {
            var articoliOrdine = _gestioneDati.GetArticoliByOrdine(idOrdine)
                .Select(a => a.IdArticolo)
                .Distinct()
                .ToList();

            if (articoliOrdine.Count < 2) return;

            foreach (var (idX, idY) in GeneraCombinazioni(articoliOrdine))
            {
                var associazioneEsistente = _gestioneDati.GetAssociazione(idX, idY);

                if (associazioneEsistente != null)
                {
                    associazioneEsistente.Frequenza++;
                    associazioneEsistente.UltimaAssociazione = DateTime.Now;
                    _gestioneDati.UpdateAssociazione(associazioneEsistente);
                }
                else
                {
                    _gestioneDati.AddAssociazione(new Associazione_Articoli()
                    {
                        IdArticolo_X = Math.Min(idX, idY),
                        IdArticolo_Y = Math.Max(idX, idY),
                        Frequenza = 1,
                        UltimaAssociazione = DateTime.Now
                    });
                }
            }
        }

        public List<Articolo> GetSuggerimenti(int idOrdine, int count = 3)
        {
            // 1. Controllo esplicito per ordine inesistente
            var ordine = _gestioneDati.RecuperaOrdine(idOrdine);
            if (ordine == null) 
            {
                return GetArticoliPopolari(count);
            }

            // 2. Recupera articoli ordine con controllo null
            var dettagliOrdine = _gestioneDati.RecuperaDettagliPerOrdine(idOrdine) ?? new List<DettaglioOrdine>();
            var articoliOrdineIds = dettagliOrdine.Select(d => d.IdArticolo).Distinct().ToList();

            // 3. Se ordine vuoto, restituisci popolari MA con controllo aggiuntivo
            if (!articoliOrdineIds.Any())
            {
                return GetArticoliPopolari(count, exclude: null); // Esclude solo se necessario
            }

            // 4. Logica normale delle associazioni
            var tutteAssociazioni = articoliOrdineIds
                .SelectMany(id => _gestioneDati.GetAssociazioniByArticolo(id))
                .Where(a => !articoliOrdineIds.Contains(a.IdArticolo_X) || 
                            !articoliOrdineIds.Contains(a.IdArticolo_Y))
                .ToList();

            return ProcessaAssociazioni(tutteAssociazioni, articoliOrdineIds, count);
        }

// Metodo helper separato per articoli popolari
        private List<Articolo> GetArticoliPopolari(int count, List<int> exclude = null)
        {
            var query = _gestioneDati.RecuperaTuttiArticoli();
    
            if (exclude != null && exclude.Any())
            {
                query = (List<Articolo>)query.Where(a => !exclude.Contains(a.IdArticolo));
            }

            return query.OrderByDescending(a => a.NumeroDiOrdini)
                .Take(count)
                .ToList();
        }

        // Metodo privato per processare le associazioni
        private List<Articolo> ProcessaAssociazioni(List<Associazione_Articoli> associazioni, 
                                                  List<int> articoliEsclusi, 
                                                  int count)
        {
            var suggerimentiPonderati = associazioni
                .GroupBy(a => articoliEsclusi.Contains(a.IdArticolo_X) 
                            ? a.IdArticolo_Y 
                            : a.IdArticolo_X)
                .Select(g => new {
                    IdArticolo = g.Key,
                    FrequenzaTotale = g.Sum(x => x.Frequenza),
                    UltimaAssociazione = g.Max(x => x.UltimaAssociazione)
                })
                .OrderByDescending(x => x.FrequenzaTotale)
                .ThenByDescending(x => x.UltimaAssociazione)
                .Take(count)
                .ToList();

            var suggerimenti = suggerimentiPonderati
                .Select(x => _gestioneDati.RecuperaArticolo(x.IdArticolo))
                .Where(a => a != null)
                .ToList();

            // Completa con articoli popolari se necessario
            if (suggerimenti.Count < count)
            {
                var articoliMancanti = count - suggerimenti.Count;
                var articoliPopolari = _gestioneDati.RecuperaTuttiArticoli()
                    .Where(a => !articoliEsclusi.Contains(a.IdArticolo) &&
                               !suggerimenti.Any(s => s.IdArticolo == a.IdArticolo))
                    .OrderByDescending(a => a.NumeroDiOrdini)
                    .Take(articoliMancanti)
                    .ToList();

                suggerimenti.AddRange(articoliPopolari);
            }

            return suggerimenti;
        }

        // Genera tutte le combinazioni possibili tra articoli
        private List<(int, int)> GeneraCombinazioni(List<int> ids)
        {
            var combinazioni = new List<(int, int)>();
            
            for (int i = 0; i < ids.Count; i++)
            {
                for (int j = i + 1; j < ids.Count; j++)
                {
                    combinazioni.Add((Math.Min(ids[i], ids[j]), Math.Max(ids[i], ids[j])));
                }
            }
            
            return combinazioni;
        }
    }
}