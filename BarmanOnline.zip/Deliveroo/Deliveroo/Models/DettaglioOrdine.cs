namespace Deliveroo.Models
{
    public class DettaglioOrdine
    {
        public int IdOrdine { get; set; }
        public int IdArticolo { get; set; }
        public int Quantita { get; set; }
        public decimal PrezzoApplicato { get; set; }
        
    }
}