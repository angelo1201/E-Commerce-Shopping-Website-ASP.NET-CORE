namespace Deliveroo.Models;

public class Articolo
{
    public int IdArticolo { get; set; }         // ID univoco dell'articolo
    public string Nome { get; set; }            // Nome dell'articolo
    public string? Foto { get; set; }           // Percorso della foto (può essere null)
    public decimal PrezzoListino { get; set; }  // Prezzo dell'articolo
    public int NumeroDiOrdini { get; set; }     // Numero di volte in cui è stato ordinato
    
    public string Descrizione { get; set; }

    // Costruttore vuoto (necessario per Entity Framework o deserializzazione)
    public Articolo() {}

    // Costruttore per inizializzare la classe con i dati
    public Articolo(int idArticolo, string nome, string? foto, decimal prezzoListino, int numeroDiOrdini, string descrizione)
    {
        IdArticolo = idArticolo;
        Nome = nome;
        Foto = foto;
        PrezzoListino = prezzoListino;
        NumeroDiOrdini = numeroDiOrdini;
        Descrizione = descrizione;
    }
}